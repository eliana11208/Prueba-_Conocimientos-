@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"></div>

                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif

<h1>CATEGORIAS</h1> 
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <!-- CSS only -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
<!-- JavaScript Bundle with Popper -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-pprn3073KE6tl6bjs2QrFaJGz5/SUsLqktiwsUTF55Jfv3qYSDhgCecCxMW52nD2" crossorigin="anonymous"></script>

</head>
<body>
    

<div id="carouselExampleCaptions" class="carousel slide" data-bs-ride="false">
  <div class="carousel-indicators">
    <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
    <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1" aria-label="Slide 2"></button>
    <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2" aria-label="Slide 3"></button>
    <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="3" aria-label="Slide 4"></button>
    <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="4" aria-label="Slide 5"></button>
    <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="5" aria-label="Slide 6"></button>
    <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="6" aria-label="Slide 7"></button>
    <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="7" aria-label="Slide 8"></button>
    <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="8" aria-label="Slide 9"></button>
    <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="9" aria-label="Slide 10"></button>
    <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="10" aria-label="Slide 11"></button>
    <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="11" aria-label="Slide 12"></button>
    <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="12" aria-label="Slide 13"></button>
    <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="13" aria-label="Slide 14"></button>
    <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="14" aria-label="Slide 15"></button>
    <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="15" aria-label="Slide 16"></button>
    <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="16" aria-label="Slide 17"></button>


  </div>
  
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="http://localhost/PRUEBA_DAVIVIENDA/resources/img/animal.jpg" class="d-block w-100" alt="...">
      <div class="carousel-caption d-none d-md-block">
      <div class='boton1'>
      <input type="image" class="btn btn-primary" src="http://localhost/PRUEBA_DAVIVIENDA/resources/img/estrella.png"  style="border: double;" height="40" width="50"/>	
      </div>		
        <h1>ANIMALES</h1>
      </div>
    
    </div>
    <div class="carousel-item">
      <img src="http://localhost/PRUEBA_DAVIVIENDA/resources/img/celebracion.jpg" class="d-block w-100" alt="...">
      <div class="carousel-caption d-none d-md-block">
      <div class='boton2'>
      <input type="image" class="btn btn-primary" src="http://localhost/PRUEBA_DAVIVIENDA/resources/img/estrella.png" style="border: double;" height="40" width="50"/>
		</div>		
        <h1>CELEBRACIONES</h1>
      </div>
    </div>
    <div class="carousel-item">
      <img src="http://localhost/PRUEBA_DAVIVIENDA/resources/img/ciencia.jpeg" class="d-block w-100" alt="...">
      <div class="carousel-caption d-none d-md-block">
      <div class='boton3'>
      <input type="image" class="btn btn-primary" src="http://localhost/PRUEBA_DAVIVIENDA/resources/img/estrella.png" style="border: double;" height="40" width="50"/>
		</div>		
        <h1>CIENCIA</h1>
      </div>
    </div>
    <div class="carousel-item">
      <img src="http://localhost/PRUEBA_DAVIVIENDA/resources/img/comida.jpg" class="d-block w-100" alt="...">
      <div class="carousel-caption d-none d-md-block">
      <div class='boton4'>
      <input type="image" class="btn btn-primary" src="http://localhost/PRUEBA_DAVIVIENDA/resources/img/estrella.png" style="border: double;" height="40" width="50"/>
		</div>		
        <h1>COMIDA</h1>
      </div>
    </div>
    <div class="carousel-item">
      <img src="http://localhost/PRUEBA_DAVIVIENDA/resources/img/deporte.jpg" class="d-block w-100" alt="...">
      <div class="carousel-caption d-none d-md-block">
      <div class='boton5'>
      <input type="image" class="btn btn-primary" src="http://localhost/PRUEBA_DAVIVIENDA/resources/img/estrella.png" style="border: double;" height="40" width="50"/>
		</div>		
        <h1>DEPORTE</h1>
      </div>
    </div>
    <div class="carousel-item">
      <img src="http://localhost/PRUEBA_DAVIVIENDA/resources/img/Economia.jpg" class="d-block w-100" alt="...">
      <div class="carousel-caption d-none d-md-block">
      <div class='boton6'>
      <input type="image" class="btn btn-primary" src="http://localhost/PRUEBA_DAVIVIENDA/resources/img/estrella.png" style="border: double;" height="40" width="50"/>
		</div>		
        <h1>ECONOMIA</h1>
      </div>
    </div>
    <div class="carousel-item">
      <img src="http://localhost/PRUEBA_DAVIVIENDA/resources/img/fashion.jpg" class="d-block w-100" alt="...">
      <div class="carousel-caption d-none d-md-block">
      <div class='boton7'>
      <input type="image" class="btn btn-primary" src="http://localhost/PRUEBA_DAVIVIENDA/resources/img/estrella.png" style="border: double;" height="40" width="50"/>
		</div>		
        <h1>FASHION</h1>
      </div>
    </div>
    <div class="carousel-item">
      <img src="http://localhost/PRUEBA_DAVIVIENDA/resources/img/historia.jpg" class="d-block w-100" alt="...">
      <div class="carousel-caption d-none d-md-block">
      <div class='boton8'>
      <input type="image" class="btn btn-primary" src="http://localhost/PRUEBA_DAVIVIENDA/resources/img/estrella.png" style="border: double;" height="40" width="50"/>
		</div>		
        <h1>HISTORIA</h1>
      </div>
    </div>
    <div class="carousel-item">
      <img src="http://localhost/PRUEBA_DAVIVIENDA/resources/img/pelicula.jpg" class="d-block w-100" alt="...">
      <div class="carousel-caption d-none d-md-block">
      <div class='boton9'>
      <input type="image" class="btn btn-primary" src="http://localhost/PRUEBA_DAVIVIENDA/resources/img/estrella.png" style="border: double;" height="40" width="50"/>
		</div>		
        <h1>PELICULAS</h1>
      </div>
    </div>
    <div class="carousel-item">
      <img src="http://localhost/PRUEBA_DAVIVIENDA/resources/img/politica.jpg" class="d-block w-100" alt="...">
      <div class="carousel-caption d-none d-md-block">
      <div class='boton10'>
      <input type="image" class="btn btn-primary" src="http://localhost/PRUEBA_DAVIVIENDA/resources/img/estrella.png" style="border: double;" height="40" width="50"/>
		</div>		
        <h1>POLITICA</h1>
      </div>
    </div>
    <div class="carousel-item">
      <img src="http://localhost/PRUEBA_DAVIVIENDA/resources/img/religion.jpg" class="d-block w-100" alt="...">
      <div class="carousel-caption d-none d-md-block">
      <div class='boton11'>
      <input type="image" class="btn btn-primary" src="http://localhost/PRUEBA_DAVIVIENDA/resources/img/estrella.png" style="border: double;" height="40" width="50"/>
		</div>		
        <h1>RELIGION</h1>
      </div>
    </div>
    <div class="carousel-item">
      <img src="http://localhost/PRUEBA_DAVIVIENDA/resources/img/tecnologia.png" class="d-block w-100" alt="...">
      <div class="carousel-caption d-none d-md-block">
      <div class='boton12'>
      <input type="image" class="btn btn-primary" src="http://localhost/PRUEBA_DAVIVIENDA/resources/img/estrella.png" style="border: double;" height="40" width="50"/>
		</div>		
        <h1>TECNOLOGIA</h1>
      </div>
    </div>
    <div class="carousel-item">
      <img src="http://localhost/PRUEBA_DAVIVIENDA/resources/img/trabajo.jpg" class="d-block w-100" alt="...">
      <div class="carousel-caption d-none d-md-block">
      <div class='boton13'>
      <input type="image" class="btn btn-primary" src="http://localhost/PRUEBA_DAVIVIENDA/resources/img/estrella.png" style="border: double;" height="40" width="50"/>
		</div>		
        <h1>TRABAJO</h1>
      </div>
    </div>
    <div class="carousel-item">
      <img src="http://localhost/PRUEBA_DAVIVIENDA/resources/img/viaje.jpg" class="d-block w-100" alt="...">
      <div class="carousel-caption d-none d-md-block">
      <div class='boton14'>
      <input type="image" class="btn btn-primary" src="http://localhost/PRUEBA_DAVIVIENDA/resources/img/estrella.png" style="border: double;" height="40" width="50"/>
		</div>		
        <h1>VIAJES</h1>
      </div>
    </div>

  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-pprn3073KE6tl6bjs2QrFaJGz5/SUsLqktiwsUTF55Jfv3qYSDhgCecCxMW52nD2" crossorigin="anonymous"></script>
</body>

<script>
    var currentSlide;
var rand;
$(document).ready(function() {
  currentSlide = Math.floor((Math.random() * $('.item').length));
  rand = currentSlide;
  $('#carousel-item').carousel(currentSlide);
  $('#carousel-item').fadeIn(1000);
  setInterval(function(){ 
    while(rand == currentSlide){
      rand = Math.floor((Math.random() * $('.item').length));
    }
    currentSlide = rand;
    $('#carousel-item').carousel(rand);
  },5000);
});
</script>
</html>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
